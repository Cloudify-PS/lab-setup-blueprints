# Change log

This file contains al notable changes to the bertvv.drupal Ansible role. This file adheres to the guidelines of [http://keepachangelog.com/](http://keepachangelog.com/). Versioning follows [Semantic Versioning](http://semver.org/).

## 1.0.0 - 2017-10-31

First release!

### Added

- Basic installation and database setup

## 1.0.1 - 2017-10-31

### Changed

- Fixed a bug where SELinux doesn't allow connecting to an external database host

